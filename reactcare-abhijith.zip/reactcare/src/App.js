import './App.css';
import Layout from './pages/layout/Layout';

function App() {
  return (
    <div className="App">
        <Layout/>
    </div>
  );
}

export default App;
