function Footer () {
    return (
        <div>I am Footer</div>
    );
}

export default Footer;